# D&D Beyond Icon Mappings

Icon mappings from the "[DDB-Importer: A D&D Beyond Integrator](https://foundryvtt.com/packages/ddb-importer)" module

All credit to [MrPrimate](https://github.com/MrPrimate/ddb-importer).
