import {MenuTitle} from "./MenuTitle.js";

class MenuTitleArtBrowserApp extends MenuTitle {}
MenuTitleArtBrowserApp._HOOK_NAME = "renderArtBrowserApp";
MenuTitleArtBrowserApp._EVT_NAMESPACE = "plutonium-art-browser-app-title-menu";
MenuTitleArtBrowserApp._TOOL_LIST = [];

export {MenuTitleArtBrowserApp};
